const Footer = () => {

}

export default Footer;